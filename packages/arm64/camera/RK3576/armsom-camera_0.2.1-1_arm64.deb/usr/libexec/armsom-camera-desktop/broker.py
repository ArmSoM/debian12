"""On-demand RKISP session broker. Install from a root-owned directory only."""
from array import array
import contextlib
import errno
from fractions import Fraction
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import socket
import stat
import struct
import subprocess
import sys
import tempfile
import time
from types import SimpleNamespace

import iq_session
import switch_mode as sw
from modes import discover_cameras

SOCKET = '/run/armsom-camera-desktop.sock'
RUNDIR = Path('/run/armsom-camera-desktop')
JOURNAL = RUNDIR / 'restore.json'
WORKER = Path(__file__).resolve().with_name('aiq_worker.py')
IQ = Path('/etc/iqfiles')
VIDEO_CLASS = Path('/sys/class/video4linux')
VENDOR_SUMS = Path('/var/lib/dpkg/info/camera-engine-rkaiq.md5sums')
MAX_IQ_BYTES = 16 * 1024 * 1024
PYTHON = '/usr/bin/python3'
MAX_REQUEST = 2048


def request(action, node, *, width=None, height=None, num=None, den=None, fd=None):
    """Called in the direct child of the camera application."""
    body = dict(action=action, node=node)
    anc = []
    if action == 'set':
        body.update(width=width,height=height,num=num,den=den)
    if action in ('set','streamoff','resume'):
        if fd is None:
            raise ValueError('Camera application did not pass its capture file descriptor')
        anc.append((socket.SOL_SOCKET,socket.SCM_RIGHTS,array('i',[fd])))
    with socket.socket(socket.AF_UNIX,socket.SOCK_SEQPACKET) as sock:
        sock.settimeout(35)
        sock.connect(SOCKET)
        sock.sendmsg([json.dumps(body).encode()],anc)
        reply=json.loads(sock.recv(2048))
    if not reply.get('ok'):
        code=reply.get('errno',errno.EIO)
        raise OSError(code, reply.get('error','Camera request failed'))


class Busy(OSError):
    def __init__(self, message):
        super().__init__(errno.EBUSY,message)


def proc_info(pid):
    """Field 2 (comm) can contain spaces and parentheses."""
    p=Path('/proc')/str(pid)
    fields=(p/'stat').read_text().rsplit(') ',1)[1].split()
    uids=(p/'status').read_text().split('\nUid:',1)[1].splitlines()[0].split()
    return int(fields[1]),int(fields[19]),tuple(map(int,uids))


def owner_for(pid,uid):
    parent,_,uids=proc_info(pid)
    if uids!=(uid,)*4 or parent<=1:
        raise ValueError('Expected a camera helper with matching peer credentials')
    _,started,uids=proc_info(parent)
    if uids!=(uid,)*4:
        raise ValueError('Camera application and helper uids differ')
    return (parent,started,uid)


def owns_node(owner,node):
    pid,started,uid=owner
    try:
        _,now,uids=proc_info(pid)
        if now!=started or uids!=(uid,)*4:
            return False
        for fd in (Path('/proc')/str(pid)/'fd').iterdir():
            with contextlib.suppress(FileNotFoundError,ProcessLookupError):
                if os.readlink(fd)==node:
                    return True
    except (FileNotFoundError,ProcessLookupError):
        pass
    return False


def isp_idle(text):
    # Require a known BSP status layout, never infer idle from a missing
    # or empty file. The Interrupt Cnt field is cumulative across sessions.
    return (re.search(r'^rkisp(?:\d+)?-vir\d+\s+ISP:0x[0-9a-f]+\s+Version:',text,re.M|re.I)
            and re.search(r'^Interrupt\s+Cnt:\s*\d+',text,re.M)
            and re.search(r'^Input\s+\S+\s+Format:',text,re.M)
            and not re.search(r'^(?:Output\s|Isp\s+(?:online|offline)\b)',text,re.M|re.I))


def guard_probe_only():
    # All CIF/ISP instances of this board must be identifiable, including
    # those with a different sensor than the target.
    isp_files=sorted(Path('/proc').glob('rkisp*-vir*'))
    cif_files=sorted(Path('/proc').glob('rkcif*'))
    if not isp_files or not cif_files:
        raise Busy('Cannot prove ISP/CIF outputs are idle')
    for p in isp_files:
        if not isp_idle(p.read_text()):
            raise Busy(f'{p.name}: active ISP or unsupported status')
    for p in cif_files:
        if not cif_idle(p.read_text()):
            raise Busy(f'{p.name}: active CIF or unsupported status')


def cif_idle(text):
    return (re.search(r'^Driver Version:\s*v\d+',text,re.M)
            and re.search(r'^Monitor Mode:\s*idle\s*$',text,re.M|re.I)
            and re.search(r'^Group Info:',text,re.M)
            and not re.search(r'^\s*(?:Input Info:|Output\b|irq statistics:|CIF\s+ISP|stream(?:ing)?\s*(?:id|\d|:)|frame\s*(?:amount|num|:))',
                              text,re.M|re.I))


def guard_other_users(owner,node,helper,worker=0):
    # Multiple clients or multiple devices in the same client cannot share
    # stock 3A ownership safely. An open camera fd counts as busy.
    group=sw.run('systemctl','show','--property=ControlGroup','--value',sw.UNIT).strip()
    owner_probes=False
    for p in Path('/proc').glob('[0-9]*'):
        pid=int(p.name)
        if pid in (os.getpid(),worker): continue
        with contextlib.suppress(FileNotFoundError,ProcessLookupError):
            comm=(p/'comm').read_text().strip()
            if comm=='rkaiq_3A_server':
                groups=[row.split(':',2)[-1] for row in (p/'cgroup').read_text().splitlines()]
                if group and group in groups: continue
                # Some BSP service wrappers move their child to the root cgroup
                # for realtime scheduling and remain its supervising parent.
                main_pid=sw.run('systemctl','show','--property=MainPID','--value',sw.UNIT).strip()
                parent=re.search(r'^PPid:\s+(\d+)$',(p/'status').read_text(),re.M)
                if (main_pid.isdecimal() and int(main_pid)>1 and parent and parent[1]==main_pid
                        and (p/'exe').samefile('/usr/bin/rkaiq_3A_server')):
                    continue
                raise Busy('Unmanaged RKAIQ server already running')
            for f in (p/'fd').iterdir():
                with contextlib.suppress(FileNotFoundError,ProcessLookupError):
                    target=os.readlink(f)
                    if not re.fullmatch(r'/dev/(video\d+|v4l-subdev\d+|media\d+)',target): continue
                    if pid in (owner[0],helper) and target==node: continue
                    if pid==owner[0] and re.fullmatch(r'/dev/(video\d+|media\d+)',target):
                        owner_probes=True
                        continue
                    raise Busy(f'Camera subsystem busy ({comm} pid {pid})')
    if owner_probes: guard_probe_only()


def parse_request(b):
    if not isinstance(b,dict) or not isinstance(b.get('node'),str) or not re.fullmatch(r'/dev/video[0-9]{1,4}',b['node']):
        raise ValueError('Invalid capture node')
    if b.get('action') in ('release','streamoff','resume') and set(b)=={'action','node'}: return None
    if b.get('action')!='set' or set(b)!={'action','node','width','height','num','den'}:
        raise ValueError('Invalid operation')
    if any(type(b[k]) is not int or not 0<b[k]<=65535 for k in ('width','height','num','den')):
        raise ValueError('Invalid native mode request')
    # V4L2 passes an interval in seconds/frame, not a frame rate.
    return Fraction(b['den'],b['num'])


def camera(node):
    found=discover_cameras(node)
    if len(found)!=1 or not found[0]['managed'] or found[0]['video']['entity']!='rkisp_mainpath':
        raise sw.Refusal('Not a unique managed mainpath')
    return found[0]


def read_regular(path):
    """Pin each component with openat. Inspect the inode before opening it for I/O."""
    if not path.is_absolute() or '..' in path.parts:
        raise sw.Refusal(f'Invalid calibration path: {path}')
    flags=os.O_PATH | os.O_NOFOLLOW | os.O_CLOEXEC
    fd=os.open('/',flags | os.O_DIRECTORY)
    try:
        protected=True
        for i,part in enumerate(path.parts[1:],1):
            st=os.fstat(fd)
            protected=protected and st.st_uid==0 and not st.st_mode & 0o022
            next_fd=os.open(part,flags | (os.O_DIRECTORY if i<len(path.parts)-1 else 0),dir_fd=fd)
            os.close(fd)
            fd=next_fd
        st=os.fstat(fd)
        if not stat.S_ISREG(st.st_mode) or st.st_size>MAX_IQ_BYTES:
            raise sw.Refusal(f'Expected a bounded regular file: {path}')
        protected=protected and st.st_uid==0 and not st.st_mode & 0o022
        # This kernel link reopens the pinned regular inode even if an untrusted
        # owner exchanges the directory entry between inspection and read.
        with open(f'/proc/self/fd/{fd}','rb') as source:
            data=source.read(MAX_IQ_BYTES+1)
        if len(data)>MAX_IQ_BYTES:
            raise sw.Refusal(f'Calibration file exceeds the size limit: {path}')
        return data,protected
    finally:
        os.close(fd)


def calibration_bytes(selected):
    if selected.parent!=IQ:
        raise sw.Refusal(f'IQ must come from the installed calibration directory: {selected}')
    data,protected=read_regular(selected)
    if protected:
        return data
    # Some vendor images retain packaging-account ownership under /etc/iqfiles.
    # Accept only the installed package's exact payload at its recorded path.
    try:
        manifest,trusted=read_regular(VENDOR_SUMS)
    except FileNotFoundError:
        manifest,trusted=read_regular(VENDOR_SUMS.with_name('camera-engine-rkaiq:arm64.md5sums'))
    if not trusted:
        raise sw.Refusal('Untrusted dpkg calibration manifest')
    name=b'etc/iqfiles/'+os.fsencode(selected.name)
    matches=[line.partition(b'  ')[0] for line in manifest.splitlines()
             if line.partition(b'  ')[2]==name]
    digest=hashlib.md5(data,usedforsecurity=False).hexdigest().encode('ascii')
    if matches!=[digest]:
        raise sw.Refusal(f'IQ does not match installed camera-engine-rkaiq calibration: {selected}')
    return data


def private_iq(cam,m,fps):
    s=cam['sensor']
    match=re.fullmatch(r'(?:m\d+_[bf]_)?(imx219|ov13850)\s+\S+',s['entity'])
    if not match: raise sw.Refusal('No calibrated backend for this sensor')
    kind=match[1]
    root=VIDEO_CLASS/Path(s['node']).name/'device/of_node'
    try:
        module,lens=[(root/('rockchip,camera-module-'+k)).read_bytes().rstrip(b'\0').decode()
                     for k in ('name','lens-name')]
    except FileNotFoundError as error:
        raise sw.Refusal(f'Missing camera module or lens identifier for {s["entity"]}') from error
    if any(not re.fullmatch(r'[A-Za-z0-9._-]+',v) for v in (module,lens)):
        raise sw.Refusal('Invalid module/lens identifier')
    exact=f'{kind}_{module}_{lens}.json'
    # Vendor filenames sometimes differ in letter case from the device tree.
    paths=[p for p in IQ.iterdir() if p.name.casefold()==exact.casefold()]
    if len(paths)!=1: raise sw.Refusal(f'Expected one installed IQ matching {exact} in {IQ}')
    selected=paths[0]
    data=calibration_bytes(selected)
    mode=SimpleNamespace(width=m['width'],height=m['height'])
    # Allow 2:1 transfer for the audited OV module only when the connected
    # driver actually enumerates the two native SBGGR10 modes and intervals.
    def native(w,h,n,d):
        return any((v['width'],v['height'],v['mbus_code'],v['fps']['numerator'],
                    v['fps']['denominator'])==(w,h,0x3007,n,d) for v in cam.get('modes',[]))
    ov_full=(kind=='ov13850' and native(2112,1568,30,1) and native(4224,3136,15,2))
    profile=iq_session.session_profile(selected,mode,float(fps) if fps.denominator!=1 else int(fps),
                                       ov_full_lsc=ov_full,data=data)
    if kind=='imx219':
        for msg in iq_session.configure_lsc(profile,mode):
            print(msg,file=sys.stderr,flush=True)
    else:
        # Never remap IMX219 geometry for OV13850. Only use the OV tables, or
        # switch the private ISP30 module off if they lack this sensor geometry.
        for main in profile.get('main_scene',[]):
            for sub in main.get('sub_scene',[]):
                common=sub.get('scene_isp30',{}).get('lsc_v2',{}).get('common',{})
                if common.get('enable') and f'{mode.width}x{mode.height}' not in {
                    item.get('name') for item in common.get('resolutionAll',[])}:
                    common['enable']=0
    return profile


def stop_worker(p):
    if p and p.poll() is None:
        p.terminate()
        try: p.wait(timeout=3)
        except subprocess.TimeoutExpired:
            p.kill(); p.wait(timeout=2)


def safe_write(path,data):
    tmp=path.with_suffix('.new')
    tmp.write_text(json.dumps(data))
    tmp.replace(path)


class Sessions:
    def __init__(self):
        self.owner=None
        self.node=None
        self.worker=None
        self.session=None
        self.mode=None
        self.suspended=False
        self.release_pending=False
        self.retry_after=0.0

    def close(self):
        if not JOURNAL.exists(): return
        rec=json.loads(JOURNAL.read_text())
        cam=camera(rec['node'])
        if sw.identity(cam)!=rec['identity']:
            raise sw.Refusal('Recovery graph differs from the saved graph')
        stop_worker(self.worker)
        self.worker=None
        # If a previous process died before it stopped the service, stop it
        # before replaying the pads; always put even failed recovery back in 3A.
        try:
            if sw.stable_unit(owned_stop=rec['stock']=='active') == 'active':
                sw.stop_stock()
            sw.replay(cam,rec['state'])
        finally:
            if rec['stock']=='active': sw.run('systemctl','start',sw.UNIT)
        if sw.current(cam)!=rec['state']: raise sw.Refusal('Stock format recovery not verified')
        JOURNAL.unlink()
        if self.session: self.session.cleanup()
        self.owner=self.node=self.worker=self.mode=self.session=None
        self.suspended=False
        self.release_pending=False
        self.retry_after=0.0

    def begin(self,body,fps,owner,helper):
        node=body['node']
        if not owns_node(owner,node):
            raise sw.Refusal('GUI does not hold the requested camera')
        # A device selector often closes the old fd and opens its successor
        # immediately, before the periodic owner check has run.
        if self.owner:
            if not owns_node(self.owner,self.node):
                self.close()
            elif self.release_pending and self.owner==owner:
                # The actual V4L fd has been closed but GstDeviceMonitor may
                # still hold raw probe descriptors for that same mainpath.
                guard_probe_only()
                self.close()
        if self.owner and (self.owner!=owner or self.node!=node):
            raise Busy('Another capture session already owns 3A')
        cam=camera(node)
        m=sw.choose(cam,body['width'],body['height'],fps)
        if self.mode==m and (self.suspended or (self.worker is not None and self.worker.poll() is None)):
            return
        guard_other_users(owner,node,helper,self.worker.pid if self.worker else 0)
        if self.owner:
            self.close()
        if JOURNAL.exists(): raise sw.Refusal('Prior recovery required')
        profile=private_iq(cam,m,fps)
        self.session=tempfile.TemporaryDirectory(dir=RUNDIR,prefix='session-')
        tmp=Path(self.session.name)
        iq=tmp/'session.json'; safe_write(iq,profile)
        config=tmp/'config.json'
        safe_write(config,dict(sensor=cam['sensor']['entity'],sensor_width=m['width'],
            sensor_height=m['height'],fps=int(fps) if fps.denominator==1 else float(fps),
            broker_pid=os.getpid(),session_iq=str(iq),ready=str(tmp/'ready')))
        cmd=[PYTHON,'-EsB',str(WORKER)]
        check=subprocess.run([*cmd,'--check',str(config)],capture_output=True,text=True,timeout=5)
        if check.returncode or (check.stdout.strip()=='setFrameRate' and fps.denominator!=1):
            raise sw.Refusal('Native AIQ API unavailable for this profile/frame interval')
        saved=sw.current(cam)
        stock=sw.stable_unit()
        safe_write(JOURNAL,dict(node=node,identity=sw.identity(cam),stock=stock,state=saved))
        self.node,self.owner,self.mode=node,owner,m
        self.suspended=False
        try:
            if stock == 'active':
                sw.stop_stock()
            guard_other_users(owner,node,helper)
            sw.apply(cam,m,fps)
            self.start_worker()
            sw.verify_mode(cam,m,fps)
        except BaseException:
            self.close()
            raise

    def start_worker(self):
        # The ready marker must belong to this process, not the previous loop.
        tmp=Path(self.session.name)
        ready=tmp/'ready'
        ready.unlink(missing_ok=True)
        self.worker=subprocess.Popen([PYTHON,'-EsB',str(WORKER),str(tmp/'config.json')],
            stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,close_fds=True)
        try:
            limit=time.monotonic()+12
            while True:
                if self.worker.poll() is not None: raise sw.Refusal('RKAIQ worker exited during prepare')
                if ready.is_file(): return
                if time.monotonic()>=limit: raise sw.Refusal('RKAIQ readiness timeout')
                time.sleep(.05)
        except BaseException:
            stop_worker(self.worker)
            self.worker=None
            raise

    def stream_event(self,action,owner,node):
        if self.owner!=owner or self.node!=node or self.release_pending or not owns_node(owner,node):
            raise Busy('Stream event does not belong to a live camera lease')
        if action=='streamoff':
            if not self.suspended:
                stop_worker(self.worker)
                self.worker=None
                self.suspended=True
            return
        if action!='resume': raise ValueError('Unknown stream event')
        if self.suspended:
            # Do not touch sensor pads, capture formats or allocated buffers.
            self.start_worker()
            self.suspended=False
        elif self.worker is None or self.worker.poll() is not None:
            raise sw.Refusal('Active RKAIQ worker unexpectedly exited')

    def tick(self):
        if not self.owner or time.monotonic()<self.retry_after: return
        # libv4l's plugin close precedes close(video_fd); never block that
        # callback waiting for a mapping held by the requesting process.
        dead_worker=not self.suspended and (not self.worker or self.worker.poll() is not None)
        can_release=not owns_node(self.owner,self.node) or dead_worker
        if self.release_pending and not can_release:
            try:
                guard_probe_only()
                can_release=True
            except (Busy,OSError):
                return
        if can_release:
            try: self.close()
            except (OSError,RuntimeError,subprocess.SubprocessError) as exc:
                self.retry_after=time.monotonic()+3
                print('Deferred camera recovery:',exc,file=sys.stderr,flush=True)

    def handle(self,c):
        pid,uid,_=struct.unpack('3i',c.getsockopt(socket.SOL_SOCKET,socket.SO_PEERCRED,12))
        owner=owner_for(pid,uid)
        data,anc,flags,_=c.recvmsg(MAX_REQUEST,socket.CMSG_SPACE(16),socket.MSG_CMSG_CLOEXEC)
        fds=[]
        try:
            for lvl,kind,val in anc:
                if (lvl,kind)==(socket.SOL_SOCKET,socket.SCM_RIGHTS):
                    rights=array('i'); rights.frombytes(val); fds.extend(rights)
            if flags&(socket.MSG_TRUNC|socket.MSG_CTRUNC): raise ValueError('Truncated request')
            b=json.loads(data); fps=parse_request(b); node=b['node']
            if b['action']=='release':
                if fds: raise ValueError('Unexpected ancillary data')
                if self.owner==owner and self.node==node:
                    if owns_node(owner,node):
                        self.release_pending=True
                        self.retry_after=time.monotonic()+.5
                    else: self.close()
                return
            st=os.stat(node,follow_symlinks=False)
            if len(fds)!=1 or not stat.S_ISCHR(st.st_mode) or os.major(st.st_rdev)!=81:
                raise ValueError('Expected V4L2 device fd')
            fst=os.fstat(fds[0])
            if not stat.S_ISCHR(fst.st_mode) or fst.st_rdev!=st.st_rdev:
                raise ValueError('FD/node mismatch')
            if b['action'] in ('resume','streamoff'):
                self.stream_event(b['action'],owner,node)
            else:
                self.begin(b,fps,owner,pid)
        finally:
            for fd in fds: os.close(fd)


def serve():
    if os.geteuid()!=0 or os.environ.get('LISTEN_PID')!=str(os.getpid()) or os.environ.get('LISTEN_FDS')!='1':
        raise RuntimeError('Must be started by the systemd socket')
    os.umask(0o077)
    meta=RUNDIR.lstat()
    if not stat.S_ISDIR(meta.st_mode) or meta.st_uid or stat.S_IMODE(meta.st_mode)!=0o700:
        raise RuntimeError('Unsafe runtime directory')
    sock=socket.socket(fileno=3)
    sock.settimeout(.4)
    sessions=Sessions()
    sessions.close()
    running=True
    def finish(sig,frame):
        nonlocal running
        running=False
    signal.signal(signal.SIGTERM,finish)
    try:
        while running:
            sessions.tick()
            try: client,_=sock.accept()
            except TimeoutError: continue
            with client:
                client.settimeout(1.0)
                try: sessions.handle(client); reply={'ok':True}
                except (ValueError,OSError,RuntimeError,subprocess.SubprocessError) as exc:
                    code=exc.errno if isinstance(exc,OSError) and exc.errno else errno.EIO
                    if isinstance(exc,ValueError): code=errno.EINVAL
                    reply={'ok':False,'error':str(exc)[:350],'errno':code}
                with contextlib.suppress(OSError):
                    client.send(json.dumps(reply).encode())
    finally:
        sessions.close()


if __name__=='__main__': serve()
