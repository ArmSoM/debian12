#!/usr/bin/env python3
"""Bench-only native-mode switch for an idle RKISP main path.

Does not start a stream, change IQ, grant privileges or install a service.
Default leaves the stock 3A daemon running. An explicit --cycle-3a tests
stopping/starting its systemd unit when the entire media subsystem is idle.
Call --restore after each trial. The private snapshot survives process errors.
"""
import argparse
import contextlib
from fractions import Fraction
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys

from modes import discover_cameras

UNIT = 'rkaiq_3A.service'
STATE = Path('/run/rk-desktop-camera-bench')
BOOT = Path('/proc/sys/kernel/random/boot_id')


class Refusal(RuntimeError):
    pass


def run(*argv):
    cmd = subprocess.run(argv, capture_output=True, text=True, timeout=10,
                         env=dict(os.environ, LC_ALL='C'))
    if cmd.returncode:
        raise Refusal(f'{argv[0]} {argv[-1]}: {cmd.stderr.strip() or cmd.stdout.strip()}')
    return cmd.stdout


def exact(pattern, text, label):
    result = re.search(pattern, text)
    if result is None:
        raise Refusal('Cannot read ' + label)
    return result.groups()


def guard_idle():
    # Check the entire board: stock 3A may own multiple virtual ISP instances.
    group = run('systemctl', 'show', '--property=ControlGroup', '--value', UNIT).strip()
    for proc in Path('/proc').glob('[0-9]*'):
        if int(proc.name) == os.getpid():
            continue
        with contextlib.suppress(FileNotFoundError, ProcessLookupError):
            comm = (proc / 'comm').read_text().strip()
            if comm == 'rkaiq_3A_server':
                groups = [s.split(':', 2)[-1] for s in (proc / 'cgroup').read_text().splitlines()]
                if group and group in groups:
                    continue
                raise Refusal(f'Unmanaged AIQ process {proc.name}; refusing to interrupt it')
            for fd in (proc / 'fd').iterdir():
                with contextlib.suppress(FileNotFoundError, ProcessLookupError):
                    if os.readlink(fd).startswith(('/dev/video', '/dev/v4l-subdev', '/dev/media')):
                        raise Refusal(f'Camera subsystem in use by {comm} (pid {proc.name})')


def pad_sequence(cam):
    s, b, i = cam['sensor'], cam['bridge'], cam['isp']
    out = []

    def add(obj, pad, kind):
        key = (obj['media'], obj['entity'], pad)
        if any((p['media'], p['entity'], p['pad']) == key for p in out):
            return
        out.append(dict(media=obj['media'], entity=obj['entity'], node=obj['node'],
                        pad=pad, kind=kind))

    add(s, s['pad'], 'raw')
    for r in cam['route'][1:-2]:
        if r['node'].startswith('/dev/v4l-subdev') and r['sink_pad'] is not None:
            add(r, r['sink_pad'], 'raw')
    if b['sink_pad'] is None:
        add(b, b['pad'], 'raw')
    add(i, i['sink_pad'], 'isp-in')
    add(i, i['source_pad'], 'isp-out')
    return out


def pad_read(p):
    return run('media-ctl', '-d', p['media'], '--get-v4l2', f'"{p["entity"]}":{p["pad"]}')


def pad_write(p, value):
    run('media-ctl', '-d', p['media'], '-V', f'"{p["entity"]}":{p["pad"]} [{value}]')


def fps_read(s):
    if s['pad'] != 0:
        raise Refusal('This v4l-utils bench backend supports sensor source pad zero only')
    result = run('v4l2-ctl', '-d', s['node'], '--get-subdev-fps')
    n, d = exact(r'Frames per second:[^\n]*?\((\d+)/(\d+)\)', result, 'sensor frame rate')
    return Fraction(int(n), int(d))


def current(cam):
    pads = []
    for p in pad_sequence(cam):
        t = pad_read(p)
        fmt, dim = exact(r'fmt:(\w+)/(\d+x\d+)', t, 'active pad format')
        crop = re.search(r'(?<![.\w])crop:(\(-?\d+,-?\d+\)/\d+x\d+)', t)
        pads.append(dict(fmt=f'{fmt}/{dim}', crop=crop[1] if crop and p['kind'].startswith('isp-') else None))
    v = cam['video_node']
    s = cam['sensor']
    t = run('v4l2-ctl', '-d', v, '--get-fmt-video')
    w, h = exact(r'Width/Height\s*:\s*(\d+)/(\d+)', t, 'capture size')
    fourcc, = exact(r"Pixel Format\s*:\s*'(\w{4})'", t, 'pixel format')
    rect = run('v4l2-ctl', '-d', v, '--get-selection=target=crop')
    crop = dict(re.findall(r'\b(left|top|width|height)[= ]+(-?\d+)', rect, re.I))
    if len(crop) != 4:
        raise Refusal('Cannot snapshot ISP output crop')
    ctrl = run('v4l2-ctl', '-d', s['node'], '--list-ctrls')
    blank = re.search(r'\bvertical_blanking\b[^\n]*?\bvalue=(-?\d+)', ctrl)
    if not blank:
        raise Refusal('Cannot preserve VBLANK on this driver')
    return dict(pads=pads, width=int(w), height=int(h), fourcc=fourcc,
                crop={k.lower():int(v) for k,v in crop.items()}, blank=int(blank[1]),
                fps=str(fps_read(s)))


def identity(cam):
    return dict(boot=BOOT.read_text().strip(), video=cam['video_node'],
                sensor=cam['sensor']['entity'], pads=pad_sequence(cam))


def output(cam, crop, w, h, fourcc):
    v = cam['video_node']
    run('v4l2-ctl', '-d', v, '--set-selection=target=crop,' +
        ','.join(f'{k}={crop[k]}' for k in ('left','top','width','height')))
    run('v4l2-ctl', '-d', v, f'--set-fmt-video=width={w},height={h},pixelformat={fourcc}')


def replay(cam, st):
    for p, value in zip(pad_sequence(cam), st['pads'], strict=True):
        pad_write(p, 'fmt:'+value['fmt']+' field:none')
        if value['crop'] is not None:
            pad_write(p, 'crop:'+value['crop'])
    output(cam, st['crop'], st['width'], st['height'], st['fourcc'])
    run('v4l2-ctl', '-d', cam['sensor']['node'], '--set-ctrl=vertical_blanking='+str(st['blank']))


def choose(cam, width, height, fps):
    matches = [m for m in cam['modes'] if (m['width'],m['height'])==(width,height) and
               Fraction(m['fps']['numerator'],m['fps']['denominator'])==fps]
    if len(matches) != 1:
        raise Refusal('Expected exactly one native sensor mode for this size and frame rate')
    return matches[0]


def apply(cam, m, fps):
    w,h = m['width'],m['height']
    s = cam['sensor']
    codes = run('v4l2-ctl','-d',s['node'],f'--list-subdev-mbus-codes={s["pad"]}')
    names = {int(k,16):v for k,v in re.findall(r'(0x[0-9a-fA-F]+): MEDIA_BUS_FMT_(\w+)',codes)}
    if m['mbus_code'] not in names:
        raise Refusal('Media-bus code changed after enumeration')
    dims=f'{w}x{h}'
    for p in pad_sequence(cam):
        mbus='YUYV8_2X8' if p['kind']=='isp-out' else names[m['mbus_code']]
        pad_write(p, f'fmt:{mbus}/{dims} field:none')
        if p['kind']=='isp-in':
            pad_write(p,f'crop:(0,0)/{dims}')
    output(cam,dict(left=0,top=0,width=w,height=h),w,h,'NV12')
    # Native mode change can preserve the *previous* VBLANK when it still fits
    # the new range. Use this driver's control default for its selected mode.
    # The vendor IMX219's G_FRAME_INTERVAL reports the nominal table interval
    # even with a longer frame length, so reading it alone is insufficient.
    controls=run('v4l2-ctl','-d',s['node'],'--list-ctrls')
    default,actual=exact(r'\bvertical_blanking\b[^\n]*?\bdefault=(\d+)[^\n]*?\bvalue=(\d+)',controls,'mode VBLANK')
    if default!=actual:
        run('v4l2-ctl','-d',s['node'],'--set-ctrl=vertical_blanking='+default)
    if fps_read(s)!=fps:
        raise Refusal('Sensor did not adopt the enumerated native frame interval')


def verify_mode(cam, m, fps):
    state=current(cam)
    size=(m['width'],m['height'])
    if (state['width'],state['height'])!=size or state['fourcc']!='NV12' or Fraction(state['fps'])!=fps:
        raise Refusal('Driver clamped the requested output or native FPS')
    suffix='/'+str(size[0])+'x'+str(size[1])
    if any(not p['fmt'].endswith(suffix) for p in state['pads']):
        raise Refusal('At least one receiver/ISP pad did not keep the native dimensions')


def stable_unit(*, owned_stop=False):
    state = run('systemctl', 'show', '-p', 'ActiveState', '--value', UNIT).strip()
    if state == 'failed' and owned_stop:
        # Some BSP wrappers return the child's 128 + SIGTERM after their ExecStop.
        props = run('systemctl', 'show', '-p', 'Result,MainPID,ExecMainCode,ExecMainStatus', UNIT)
        status = dict(line.split('=', 1) for line in props.splitlines() if '=' in line)
        if (status.get('Result') == 'exit-code' and status.get('MainPID') == '0'
                and status.get('ExecMainCode') == '1' and status.get('ExecMainStatus') == '143'
                and not any(os.path.realpath(exe) == '/usr/bin/rkaiq_3A_server'
                            for exe in Path('/proc').glob('[0-9]*/exe'))):
            run('systemctl', 'reset-failed', UNIT)
            state = run('systemctl', 'show', '-p', 'ActiveState', '--value', UNIT).strip()
    if state not in ('active','inactive'):
        raise Refusal(f'{UNIT} state is {state}; no change made')
    return state


def stop_stock():
    run('systemctl', 'stop', UNIT)
    if stable_unit(owned_stop=True) != 'inactive':
        raise Refusal('Stock 3A server did not stop')


def transaction(cam, st, m, fps, cycle):
    service_was=stable_unit()
    guard_idle()
    if cycle and service_was=='active':
        stop_stock()
    try:
        guard_idle()
        if m is None:
            replay(cam, st)
        else:
            apply(cam, m, fps)
    finally:
        if cycle and service_was=='active':
            run('systemctl','start',UNIT)
    if stable_unit()!=service_was:
        raise Refusal('3A service changed state')
    if m is None:
        if current(cam)!=st:
            raise Refusal('Restored state differs from saved state')
    else:
        verify_mode(cam,m,fps)


def main():
    import fcntl  # Only the board-side lock needs Linux fcntl.
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--device', required=True)
    actions=parser.add_mutually_exclusive_group(required=True)
    actions.add_argument('--mode',metavar='WIDTHxHEIGHT')
    actions.add_argument('--restore',action='store_true')
    parser.add_argument('--fps',type=Fraction,help='native frames/sec, e.g. 30 or 15/2')
    parser.add_argument('--cycle-3a',action='store_true',help='also stop/start the stock service; bench use only')
    a=parser.parse_args()
    if bool(a.mode)!=(a.fps is not None):
        parser.error('--mode requires --fps; --restore does not take --fps')
    if os.geteuid()!=0:
        raise Refusal('Bench operation requires root to check all video consumers')
    STATE.mkdir(mode=0o700,exist_ok=True)
    meta=STATE.lstat()
    if not stat.S_ISDIR(meta.st_mode) or meta.st_uid!=0 or stat.S_IMODE(meta.st_mode)!=0o700:
        raise Refusal('Unsafe bench snapshot directory')
    with (STATE/'lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        found=discover_cameras(a.device)
        if len(found)!=1 or not found[0]['managed']:
            raise Refusal('Unmanaged or ambiguous camera/main path')
        cam=found[0]
        if cam['video']['entity'] != 'rkisp_mainpath':
            raise Refusal('Bench setup supports the ISP main path only')
        guard_idle()
        identity_now=identity(cam)
        path=STATE/(Path(cam['video_node']).name+'.json')
        if a.restore:
            rec=json.loads(path.read_text())
            if rec['identity']!=identity_now:
                raise Refusal('Snapshot does not belong to the active graph on this boot')
            transaction(cam,rec['state'],None,None,a.cycle_3a)
            path.unlink()
            print('Verified restoration of sensor, capture formats and frame interval')
            return
        w,h=map(int,a.mode.lower().split('x'))
        m=choose(cam,w,h,a.fps)
        if path.exists():
            raise Refusal(f'Pending snapshot for {a.device}; use --restore before trying another mode')
        stock=stable_unit()
        st=current(cam)
        with path.open('x') as f:
            json.dump(dict(identity=identity_now,state=st,service=stock),f)
            f.flush()
            os.fsync(f.fileno())
        try:
            transaction(cam,st,m,a.fps,a.cycle_3a)
        except (Exception, KeyboardInterrupt) as problem:
            try:
                if stable_unit()!=stock:
                    run('systemctl','start' if stock=='active' else 'stop',UNIT)
                transaction(cam,st,None,None,a.cycle_3a)
            except (Exception, KeyboardInterrupt) as restore_error:
                raise Refusal(f'{problem}; rollback unverified: {restore_error}. Snapshot retained: {path}') from problem
            path.unlink()
            raise
        print(f'Configured native {w}x{h} @ {a.fps}; frames/3A/image quality not tested. Use --restore after the trial.')


if __name__=='__main__':
    try:
        main()
    except (OSError, ValueError, RuntimeError, subprocess.TimeoutExpired) as exc:
        sys.exit(str(exc))
