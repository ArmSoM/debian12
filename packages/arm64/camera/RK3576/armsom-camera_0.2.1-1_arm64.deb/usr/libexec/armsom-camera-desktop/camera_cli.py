#!/usr/bin/python3
"""Capture from an ArmSoM RKISP camera using its native sensor modes."""
import argparse
from contextlib import contextmanager
from fractions import Fraction
import math
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import tempfile
import time

from modes import discover_cameras


PLUGIN_DIR = Path("/usr/libexec/armsom-camera-desktop/gstreamer-1.0")
SENSOR = re.compile(r"(?:(m\d+)_[bf]_)?(imx219|ov13850)\s+\S+")


def cameras_found(inventory):
    result = []
    for camera in inventory:
        if not camera["managed"] or camera["video"]["entity"] != "rkisp_mainpath":
            continue
        sensor = SENSOR.fullmatch(camera["sensor"]["entity"])
        if not sensor or not re.fullmatch(r"/dev/video\d+", camera["video_node"]):
            continue
        # The module index is from the board DT. It can differ from the
        # physical port number, so only use a CAMn name when discovery mapped it.
        fallback = "-".join(s for s in (sensor[2], sensor[1]) if s)
        key = camera.get("connector", fallback).lower()
        modes = {(m["width"], m["height"], Fraction(m["fps"]["numerator"], m["fps"]["denominator"]))
                 for m in camera["modes"]}
        result.append((key, sensor[2], camera["video_node"], sorted(modes)))
    return sorted(result)


def select_camera(cameras, wanted):
    if not cameras:
        raise ValueError("No supported sensor on an enabled RKISP capture route")
    if wanted is None:
        return cameras[0]
    choices = [c for c in cameras if wanted.lower() in c[:3]]
    if len(choices) == 1:
        return choices[0]
    if choices:
        raise ValueError(f"Camera '{wanted}' is ambiguous. Choose from " +
                         ", ".join(f"{c[0]} ({c[2]})" for c in choices))
    raise ValueError(f"Unknown camera '{wanted}'. Run armsom-camera list")


def select_mode(modes, size, rate, action):
    options = [(w, h, fps) for w, h, fps in modes
               if (size is None or (w, h) == size) and (rate is None or fps == rate)]
    if not options:
        available = ", ".join(f"{w}x{h}@{fps}" for w, h, fps in modes
                              if size is None or (w, h) == size)
        raise ValueError("Unsupported resolution or frame rate. " +
                         (f"Available: {available}" if available else "Run armsom-camera list"))
    if action == "photo":
        return max(options, key=lambda m: (m[0] * m[1], m[2]))
    return max(options, key=lambda m: (m[2], m[0] * m[1]))


def size_value(text):
    match = re.fullmatch(r"([1-9]\d*)[xX×]([1-9]\d*)", text)
    if not match:
        raise argparse.ArgumentTypeError("use WIDTHxHEIGHT")
    return int(match[1]), int(match[2])


def rate_value(text):
    try:
        value = Fraction(text)
    except (ValueError, ZeroDivisionError):
        value = 0
    if value <= 0:
        raise argparse.ArgumentTypeError("use a positive rate, e.g. 30, 7.5 or 15/2")
    return value


def seconds_value(text):
    value = float(text)
    if not math.isfinite(value) or value <= 0:
        raise argparse.ArgumentTypeError("use a positive duration in seconds")
    return value


def arguments(argv):
    parser = argparse.ArgumentParser(prog="armsom-camera", description=__doc__)
    sub = parser.add_subparsers(dest="action", required=True)
    sub.add_parser("list", help="show connected cameras and native modes")
    for name, help_text in (("preview", "view live video"), ("photo", "save a JPEG"),
                            ("video", "record an H.264 MP4")):
        cmd = sub.add_parser(name, help=help_text)
        cmd.add_argument("--camera", help="camera ID from 'list' (default: first listed)")
        cmd.add_argument("--size", type=size_value, help="native WIDTHxHEIGHT")
        cmd.add_argument("--fps", type=rate_value, help="native frame rate for that resolution")
        if name in ("photo", "video"):
            cmd.add_argument("--output", "-o", type=Path, required=True)
        if name in ("preview", "video"):
            cmd.add_argument("--duration", type=seconds_value, help="seconds, or Ctrl+C to stop")
        if name == "preview":
            cmd.add_argument("--display", choices=("auto", "kms"), default="auto",
                             help="desktop display (default), or local DRM/KMS output")
    return parser.parse_args(argv)


@contextmanager
def output_file(destination):
    if destination is None:
        yield None
        return
    # Leave an existing capture intact if negotiation or MP4 finalization fails.
    fd, name = tempfile.mkstemp(prefix=".armsom-camera-", dir=destination.parent)
    os.close(fd)
    temporary = Path(name)
    try:
        yield temporary
        if not temporary.stat().st_size:
            raise OSError("Capture produced no data")
        os.replace(temporary, destination)
    finally:
        temporary.unlink(missing_ok=True)


def load_gstreamer():
    try:
        import gi
        gi.require_version("Gst", "1.0")
        from gi.repository import GLib, Gst
    except (ValueError, ImportError) as error:
        raise RuntimeError("GStreamer Python bindings are unavailable") from error
    Gst.init(None)
    return Gst, GLib


def encoder(Gst, mode):
    # Skip encoders whose input template excludes this size/rate, e.g. a
    # software fallback advertising only HD on a full-resolution sensor mode.
    w, h, rate = mode
    caps = Gst.Caps.from_string(f"video/x-raw,width={w},height={h},"
                                f"framerate={rate.numerator}/{rate.denominator}")
    for name, properties in (("mpph264enc", ""), ("x264enc", "tune=zerolatency speed-preset=ultrafast"),
                             ("openh264enc", "")):
        factory = Gst.ElementFactory.find(name)
        if factory and factory.can_sink_any_caps(caps):
            return f"{name} {properties}"
    raise RuntimeError(f"No H.264 encoder supports {w}x{h} at {rate} fps")


def preview_sink(display):
    if display == "kms":
        return "kmssink"
    if os.environ.get("WAYLAND_DISPLAY"):
        return "waylandsink"
    if os.environ.get("DISPLAY"):
        return "ximagesink"
    raise ValueError("No desktop display. Use --display kms with a local DRM/KMS screen")


def capture(args, camera, mode, output):
    key, _, node, _ = camera
    w, h, rate = mode
    caps = (f"video/x-raw,format=NV12,width={w},height={h},"
            f"framerate={rate.numerator}/{rate.denominator}")
    os.environ["ARMSOM_DESKTOP_CAMERA"] = "1"
    os.environ["ARMSOM_CAMERA_LABEL_" + Path(node).name] = key
    os.environ["ARMSOM_CAMERA_CAPS_" + Path(node).name] = caps
    existing = os.environ.get("GST_PLUGIN_PATH_1_0", os.environ.get("GST_PLUGIN_PATH", ""))
    os.environ["GST_PLUGIN_PATH_1_0"] = os.pathsep.join(filter(None, (str(PLUGIN_DIR), existing)))
    Gst, GLib = load_gstreamer()
    skipped = math.ceil(rate) if args.action == "photo" else 0
    if args.action == "photo":
        tail = "videoconvert ! video/x-raw,format=I420 ! jpegenc ! filesink name=output"
    elif args.action == "video":
        tail = f"videoconvert ! {encoder(Gst, mode)} ! h264parse ! mp4mux ! filesink name=output"
    else:
        tail = ("queue max-size-buffers=2 max-size-bytes=0 max-size-time=0 leaky=downstream ! "
                f"videoconvert ! videoscale ! {preview_sink(args.display)} sync=true")
    try:
        pipeline = Gst.parse_launch(
            f"armsomv4l2src name=camera device={node} ! capsfilter name=mode caps={caps} ! {tail}")
    except GLib.Error as error:
        raise RuntimeError(error.message) from error
    if output is not None:
        pipeline.get_by_name("output").set_property("location", str(output))
    if args.action == "photo":
        pipeline.get_by_name("camera").set_property("num-buffers", skipped + 1)
    started = None
    last_frame = None
    frames = 0

    def on_frame(pad, info):
        nonlocal started, last_frame, frames
        frames += 1
        last_frame = time.monotonic()
        if started is None:
            started = last_frame
        return Gst.PadProbeReturn.DROP if frames <= skipped else Gst.PadProbeReturn.OK

    pipeline.get_by_name("mode").get_static_pad("src").add_probe(Gst.PadProbeType.BUFFER, on_frame)
    bus = pipeline.get_bus()
    duration = getattr(args, "duration", None)
    drain_deadline = None
    try:
        opening = time.monotonic()
        state = pipeline.set_state(Gst.State.PLAYING)
        while True:
            try:
                msg = bus.timed_pop_filtered(100 * Gst.MSECOND, Gst.MessageType.ERROR | Gst.MessageType.EOS)
                if msg and msg.type == Gst.MessageType.ERROR:
                    error, debug = msg.parse_error()
                    raise RuntimeError(f"{msg.src.get_name()}: {error.message}" +
                                       (f" ({debug})" if debug else ""))
                if msg:
                    if frames <= skipped:
                        raise RuntimeError("Camera ended before delivering a frame")
                    break
                if state == Gst.StateChangeReturn.FAILURE:
                    raise RuntimeError("GStreamer could not start the capture")
                now = time.monotonic()
                if drain_deadline is not None:
                    if now > drain_deadline:
                        raise RuntimeError("Timed out finalizing the capture")
                    continue
                # Allow the broker's 35-second mode transaction at startup.
                # Repeated driver buffers flagged as corrupt never reach this pad.
                seen = last_frame
                if seen is None and now - opening > 60:
                    raise RuntimeError("Timed out waiting for the first camera frame")
                if seen is not None and now - seen > max(10, 3 / rate):
                    raise RuntimeError("The camera pipeline stopped delivering frames")
                if duration is None or started is None or now - started < duration:
                    continue
            except KeyboardInterrupt:
                if args.action == "photo" or not frames or drain_deadline is not None:
                    raise
            if not pipeline.send_event(Gst.Event.new_eos()):
                raise RuntimeError("GStreamer refused the end-of-stream request")
            drain_deadline = time.monotonic() + 15
    finally:
        pipeline.set_state(Gst.State.NULL)


def main(argv=None):
    args = arguments(argv)
    cameras = cameras_found(discover_cameras())
    if args.action == "list":
        if not cameras:
            print("No supported camera detected")
        for key, model, node, modes in cameras:
            print(f"{key}  {model.upper()}  {node}")
            for width, height, rate in modes:
                exact = f" ({rate})" if rate.denominator != 1 else ""
                print(f"  {width}x{height}  {float(rate):g} fps{exact}")
        return
    camera = select_camera(cameras, args.camera)
    mode = select_mode(camera[3], args.size, args.fps, args.action)
    print(f"{camera[0]}  {mode[0]}x{mode[1]}  {float(mode[2]):g} fps", flush=True)
    destination = getattr(args, "output", None)
    with output_file(destination) as output:
        capture(args, camera, mode, output)
    if destination is not None:
        print(destination)


if __name__ == "__main__":
    signal.signal(signal.SIGTERM, signal.default_int_handler)
    try:
        main()
    except KeyboardInterrupt:
        sys.exit(130)
    except (OSError, ValueError, RuntimeError, subprocess.SubprocessError) as error:
        sys.exit(f"armsom-camera: {error}")
