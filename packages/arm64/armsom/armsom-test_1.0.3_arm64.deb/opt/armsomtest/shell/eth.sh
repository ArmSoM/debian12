#!/bin/bash

# 1. 自动读取并获取 BOARD_ID
BOARD_ID=$(cat /proc/device-tree/compatible 2>/dev/null | tr '\0' '\n' | head -1 | cut -d ',' -f2 | cut -d '-' -f2-)


echo "=== 开始网口测试 ==="
echo "[INFO] 当前检测到的 BOARD_ID: [$BOARD_ID]"

# 2. 根据 BOARD_ID 动态配置网口参数（请按实际板卡需求修改）
case "$BOARD_ID" in
    "armsom-sige1")
        # GMAC1为千兆口，RTL8125为2.5G口；按驱动节点取实际网卡名。
        case "${1:-1000}" in
            1000)
                NET_PATH="/sys/bus/platform/drivers/rk_gmac-dwmac/*/net/*"
                EXPECTED_SPEED=1000
                TARGET_IP="192.168.10.1"
                ;;
            2500)
                NET_PATH="/sys/bus/pci/drivers/r8169/*/net/*"
                EXPECTED_SPEED=""  # 此口只检查 IPv4 和公网连通性
                TARGET_IP="223.5.5.5"
                ;;
            *) echo "[FAIL] 参数应为1000或2500"; exit 1 ;;
        esac
        IFACE=$(ls -d $NET_PATH 2>/dev/null | awk -F/ 'NR == 1 {print $NF}')
        ;;
    "armsom-aim7-io")
        IFACE="end0"
        EXPECTED_SPEED=1000
        TARGET_IP=$(ip -4 route show default dev "$IFACE" | awk '/via/ {print $3; exit}')
        ;;
  "armsom-cm5-io")
        IFACE="end0"
        EXPECTED_SPEED=1000
        TARGET_IP="192.168.10.1"
        ;;
    "armsom-w3")
        IFACE="eth0"
        EXPECTED_SPEED=1000
        TARGET_IP="192.168.10.1"
        ;;
    "armsom-p2pro")
        IFACE="end0"
        EXPECTED_SPEED=100   # 百兆网口示例
        TARGET_IP="192.168.10.1"
        ;;
    "sige6")
        IFACE="eth0"
        EXPECTED_SPEED=1000
        TARGET_IP="192.168.10.1"
        ;;
    "armsom-sige7s")
        IFACE="enP4p65s0"
        EXPECTED_SPEED=1000
        TARGET_IP="192.168.10.1"
        ;;
    "armsom-cm7s-io")
        IFACE="end1"
        EXPECTED_SPEED=1000
        TARGET_IP="192.168.10.1"
        ;;
    *)
        # 未匹配到具体型号时的默认策略
        IFACE="end0"
        EXPECTED_SPEED=1000
        TARGET_IP="192.168.10.1"
        echo "[WARN] 未知板卡类型 [$BOARD_ID]，使用默认配置 (网口: $IFACE)"
        ;;
esac

if [ -n "$EXPECTED_SPEED" ]; then
    echo "[INFO] 测试网口: $IFACE, 预期速率: ${EXPECTED_SPEED}Mbps, 目标网关: $TARGET_IP"
else
    echo "[INFO] 测试网口: $IFACE，要求获取 IPv4 地址并能访问公网"
fi

# 3. 检测网卡节点是否存在
if [ -z "$IFACE" ] || [ ! -d "/sys/class/net/$IFACE" ]; then
    echo "[FAIL] 网卡 $IFACE 不存在"
    exit 1
fi

# 4. 检测物理网线连接状态 (Carrier)
CARRIER=$(cat /sys/class/net/$IFACE/carrier 2>/dev/null)
if [ "$CARRIER" != "1" ]; then
    echo "[FAIL] 网线未插入或链路处于 Down 状态"
    exit 2
fi
echo "[PASS] 物理网线连接正常"

# 5. 读取网口速率和双工模式并校验
SPEED=$(cat /sys/class/net/$IFACE/speed 2>/dev/null)
DUPLEX=$(cat /sys/class/net/$IFACE/duplex 2>/dev/null)
echo "[INFO] 实际协商速率: ${SPEED} Mbps, 双工: ${DUPLEX}"

if [ -n "$EXPECTED_SPEED" ]; then
    if { [ "$BOARD_ID" = "armsom-aim7-io" ] || [ "$BOARD_ID" = "armsom-sige1" ]; } &&
       [ "$SPEED" != "$EXPECTED_SPEED" ]; then
        echo "[FAIL] 网口协商速率 ${SPEED}Mbps，要求 ${EXPECTED_SPEED}Mbps"
        exit 1
    fi
    if [ "$SPEED" -lt "$EXPECTED_SPEED" ]; then
        echo "[WARN] 网口速率异常 (实际: ${SPEED}M, 预期: ${EXPECTED_SPEED}M)"
    fi
fi

# 6. 检测 IPv4 地址获取情况
IP=$(ip -4 addr show $IFACE | grep -oP '(?<=inet\s)\d+(\.\d+){3}')
if [ -z "$IP" ]; then
    echo "[FAIL] 未获取到 IPv4 地址"
    exit 3
fi
echo "[PASS] 已获取 IP 地址: $IP"


if [ "$BOARD_ID" = "armsom-aim7-io" ]; then
    [ -n "$TARGET_IP" ] && ping -I "$IFACE" -c 3 -W 2 "$TARGET_IP" || {
        echo "[FAIL] 有线网关通信失败"; exit 1;
    }
elif [ -z "$EXPECTED_SPEED" ]; then
    if ! ping -4 -n -I "$IFACE" -c 2 -W 2 "$TARGET_IP" >/dev/null 2>&1 &&
       [ "$(curl -4 -s --noproxy '*' --interface "if!$IFACE" --max-time 5 -o /dev/null -w '%{http_code}' https://connectivitycheck.platform.hicloud.com/generate_204)" != 204 ]; then
        echo "[FAIL] $IFACE 已获取 IPv4 地址，但公网连通性检测失败"
        exit 1
    fi
    echo "[PASS] $IFACE 可以访问公网"
fi

echo "=== 板卡 [$BOARD_ID] 网口 [$IFACE] 测试完成：PASS ==="
exit 0