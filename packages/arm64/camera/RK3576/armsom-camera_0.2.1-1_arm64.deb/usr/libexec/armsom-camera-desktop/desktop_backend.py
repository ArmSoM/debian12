#!/usr/bin/python3
"""Unprivileged libv4l adapter. Send writes to the socket-activated owner."""
import errno
import os
import re
import sys

from modes import discover_cameras
from switch_mode import fps_read, pad_read, pad_sequence


def main():
    op, device, *values = sys.argv[1:]
    if not re.fullmatch(r'/dev/video[0-9]+', device):
        return errno.ENODEV
    # Child tools should always inspect the underlying kernel device.
    os.environ.pop('ARMSOM_DESKTOP_CAMERA', None)
    if op in ('set', 'release', 'streamoff', 'resume'):
        from broker import request
        if op == 'set':
            w, h, n, d, flag, fd = values
            if flag != '--fd' or fd != '3':
                return errno.EINVAL
            request('set', device, width=int(w), height=int(h),
                    num=int(n), den=int(d), fd=int(fd))
        elif op in ('streamoff', 'resume'):
            if values != ['--fd', '3']:
                return errno.EINVAL
            request(op, device, fd=3)
        elif values:
            return errno.EINVAL
        else:
            request('release', device)
        return 0
    if op not in ('get', 'list') or values:
        return errno.EINVAL
    cams = discover_cameras(device)
    if len(cams) != 1 or not cams[0]['managed']:
        return errno.ENODEV
    c = cams[0]
    if c['video']['entity'] != 'rkisp_mainpath':
        return errno.ENODEV
    if op == 'list':
        print('NAME', c['sensor']['entity'])
        for mode in c['modes']:
            i = mode['interval']
            print('MODE', mode['width'], mode['height'], i['numerator'], i['denominator'])
    else:
        t = pad_read(pad_sequence(c)[0])
        dim = re.search(r'fmt:\w+/(\d+)x(\d+)', t)
        if not dim:
            return errno.EIO
        fps = fps_read(c['sensor'])
        print('MODE', *dim.groups(), fps.denominator, fps.numerator)
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (ValueError, KeyError, ArithmeticError):
        sys.exit(errno.EINVAL)
    except (OSError, RuntimeError) as e:
        print(e, file=sys.stderr)
        sys.exit(getattr(e, 'errno', None) or errno.EIO)
