"""Select an encoder for ArmSoM-managed desktop cameras."""

import ctypes
from pathlib import Path
import re
import subprocess
import sys


def rockchip_soc(compatible=Path("/proc/device-tree/compatible")):
    try:
        entries = compatible.read_bytes().split(b"\0")
    except OSError:
        return None
    for entry in entries:
        if re.fullmatch(rb"rockchip,(rk[0-9]+[a-z0-9]*|rv[0-9]+[a-z0-9]*)", entry):
            return entry.decode("ascii").split(",")[1]
    return None


def probe_mpp():
    # Public rk_type.h values: MPP_CTX_ENC and MPP_VIDEO_CodingAVC.
    enc, avc = 1, 7
    try:
        lib = ctypes.CDLL("librockchip_mpp.so.1")
        ptr = ctypes.c_void_p
        lib.mpp_check_support_format.argtypes = [ctypes.c_int, ctypes.c_int]
        lib.mpp_create.argtypes = [ctypes.POINTER(ptr), ctypes.POINTER(ptr)]
        lib.mpp_init.argtypes = [ptr, ctypes.c_int, ctypes.c_int]
        lib.mpp_destroy.argtypes = [ptr]
        if lib.mpp_check_support_format(enc, avc):
            return False
        ctx, api = ptr(), ptr()
        try:
            return (lib.mpp_create(ctypes.byref(ctx), ctypes.byref(api)) == 0
                    and bool(ctx) and lib.mpp_init(ctx, enc, avc) == 0)
        finally:
            if ctx:
                lib.mpp_destroy(ctx)
    except (OSError, AttributeError):
        return False


def available(args, env):
    try:
        status = subprocess.run(args, env=env, timeout=4, stdin=subprocess.DEVNULL,
                                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except (OSError, subprocess.TimeoutExpired):
        return False
    return status.returncode == 0


def prefer_hardware(app, env):
    soc = rockchip_soc()
    if not soc or not any(value for key, value in env.items()
                          if key.startswith("ARMSOM_CAMERA_LABEL_video")):
        return False
    # Run the vendor library outside the launcher so a failed or blocked
    # initialization cannot prevent opening the desktop application.
    if not available([sys.executable, "-I", __file__], env):
        print(f"ArmSoM {soc}: H.264 hardware initialization unavailable; using application defaults", file=sys.stderr)
        return False
    if app == "cheese":
        if not available(["gst-inspect-1.0", "mpph264enc"], env):
            print(f"ArmSoM {soc}: GStreamer mpph264enc unavailable; using application defaults", file=sys.stderr)
            return False
        ranks = [rank for rank in env.get("GST_PLUGIN_FEATURE_RANK", "").split(",") if rank]
        if not any(rank.partition(":")[0].strip() == "mpph264enc" for rank in ranks):
            env["GST_PLUGIN_FEATURE_RANK"] = ",".join([*ranks, "mpph264enc:1024"])
    print(f"ArmSoM {soc}: hardware H.264 available for {app}", file=sys.stderr)
    return True


if __name__ == "__main__":
    sys.exit(0 if probe_mpp() else 1)
