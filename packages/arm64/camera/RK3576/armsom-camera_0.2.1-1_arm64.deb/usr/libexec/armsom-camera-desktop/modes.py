#!/usr/bin/env python3
"""Discover Rockchip ISP routes and exact sensor intervals without changing any device."""

import argparse
import errno
import itertools
import json
import os
import re
import struct
import subprocess
import sys
from dataclasses import dataclass, field
from fractions import Fraction
from pathlib import Path


@dataclass
class Entity:
    name: str
    node: str = ""
    sensor: bool = False


@dataclass
class Graph:
    media: str
    model: str = ""
    driver: str = ""
    entities: dict = field(default_factory=dict)
    # Enabled data links only: (source entity, source pad, sink entity, sink pad).
    links: set = field(default_factory=set)


def parse_graph(media, topology):
    graph = Graph(media)
    entity = pad = None
    for line in topology.splitlines():
        if not line.strip():
            continue
        header = re.match(r"^(model|driver)\s+(.+)$", line)
        if header and not line.startswith("driver version"):
            setattr(graph, header[1], header[2].strip())
        match = re.match(r"^- entity \d+: (.+) \(\d+ pads?, \d+ links?\)", line)
        if match:
            entity = Entity(match[1])
            graph.entities[entity.name] = entity
            pad = None
            continue
        if entity is None:
            continue
        if re.search(r"\bsubtype Sensor\b", line, re.I):
            entity.sensor = True
        node = re.search(r"device node name (\S+)", line)
        if node:
            entity.node = node[1]
        match = re.match(r"\s*pad(\d+):", line)
        if match:
            pad = int(match[1])
        link = re.match(r'\s*(->|<-) "([^"]+)":(\d+) \[([^\]]*)\]', line)
        if pad is not None and link and "ENABLED" in re.split(r"[,\s]+", link[4]):
            local = (entity.name, pad)
            remote = (link[2], int(link[3]))
            graph.links.add(local + remote if link[1] == "->" else remote + local)
    return graph


def _step(graph, name, sink, source):
    return dict(media=graph.media, entity=name, node=graph.entities[name].node,
                sink_pad=sink, source_pad=source)


def _sensor_paths(graph, name, source, visited=()):
    """Trace enabled incoming links backwards, excluding metadata and unrelated nodes."""
    if name in visited or name not in graph.entities:
        return
    entity = graph.entities[name]
    if entity.sensor:
        if entity.node:
            yield [_step(graph, name, None, source)]
        return
    for start, src, end, sink in sorted(graph.links):
        if end == name:
            for path in _sensor_paths(graph, start, src, visited + (name,)):
                yield path + [_step(graph, name, sink, source)]


def _routes(graphs, isp_graph, video):
    isp = "rkisp-isp-subdev"
    for start, src, end, sink in sorted(isp_graph.links):
        if (start, end) != (isp, video):
            continue
        tail = [_step(isp_graph, isp, 0, src), _step(isp_graph, video, sink, None)]
        for bridge, bridge_pad, target, isp_pad in sorted(isp_graph.links):
            if target != isp or isp_pad != 0 or bridge not in isp_graph.entities:
                continue
            for path in _sensor_paths(isp_graph, bridge, bridge_pad):
                yield path + tail
            # RK BSP split graph: the enabled ISP input is named for its CIF media
            # model. Follow that CIF's actual VC0 path rather than a global sensor index.
            if not bridge.startswith("rkcif"):
                continue
            for cif in graphs:
                if cif.model != bridge or not cif.driver.startswith("rkcif"):
                    continue
                for name in cif.entities:
                    if not re.fullmatch(r"stream_cif_(?:mipi|dvp)_id0", name):
                        continue
                    for path in _sensor_paths(cif, name, None):
                        # The CIF DMA capture node is a sibling of the ISP feed. Keep
                        # its upstream CSI receiver, never configure its video pad.
                        yield path[:-1] + [_step(isp_graph, bridge, None, bridge_pad)] + tail


def _unmanaged(node, reason):
    return {"video_node": node, "managed": False, "reason": reason, "modes": []}


def resolve_routes(graphs, video_node=None):
    cameras = []
    for graph in graphs:
        if not graph.driver.startswith("rkisp") or "rkisp-isp-subdev" not in graph.entities:
            continue
        for name in ("rkisp_mainpath", "rkisp_selfpath"):
            entity = graph.entities.get(name)
            if not entity or not entity.node or (video_node and video_node != entity.node):
                continue
            paths = list(_routes(graphs, graph, name))
            if len(paths) != 1:
                cameras.append(_unmanaged(entity.node, "ambiguous-route" if paths else "no-enabled-route"))
                continue
            route = paths[0]
            sensor, bridge, isp, video = route[0], route[-3], route[-2], route[-1]
            # CIF capture DMA nodes are siblings of the sensor -> ISP path.
            # On RK3588 their sysfs parent need not equal the parent of any
            # of the receiver subdevices. The media graph is authoritative.
            media_ids = {p["media"] for p in route}
            auxiliaries = sorted({(e.node, e.name) for g in graphs
                                  if g.media in media_ids and g.driver.startswith(("rkisp", "rkcif"))
                                  for e in g.entities.values()
                                  if e.name != "rkisp_mainpath" and
                                  re.fullmatch(r"/dev/(?:video|v4l-subdev)[0-9]+", e.node)})
            cameras.append(dict(video_node=entity.node, managed=True, reason="rkisp",
                                sensor=dict(sensor, pad=sensor["source_pad"]),
                                bridge=dict(bridge, pad=bridge["source_pad"]), isp=isp,
                                video=dict(video, pad=video["sink_pad"]), route=route,
                                auxiliary=[dict(node=n, entity=e) for n, e in auxiliaries]))
    return cameras


# linux/v4l2-subdev.h. These 32-bit word-only structs have the same layout on
# armhf and arm64. All reserved fields, including stream in newer kernels, are zero.
_ACTIVE = 1
_CODE = (2, 12)
_SIZE = (74, 16)
_INTERVAL = (75, 16)


def _rows(ioctl, fd, operation, index_word, fields):
    number, words = operation
    layout = struct.Struct("=" + str(words) + "I")
    request = (3 << 30) | (layout.size << 16) | (ord("V") << 8) | number
    for index in itertools.count():
        record = [0] * words
        record[:len(fields)] = fields
        record[index_word] = index
        buf = bytearray(layout.pack(*record))
        try:
            ioctl(fd, request, buf)
        except OSError as exc:
            if exc.errno == errno.EINVAL:
                return
            raise
        yield layout.unpack(buf)


def _ratio(value):
    return {"numerator": value.numerator, "denominator": value.denominator}


def enumerate_pad(fd, pad, ioctl):
    modes, ranges = set(), set()
    for fmt in _rows(ioctl, fd, _CODE, 1, [pad, 0, 0, _ACTIVE]):
        code = fmt[2]
        code_sizes = set()
        for size in _rows(ioctl, fd, _SIZE, 0, [0, pad, code, 0, 0, 0, 0, _ACTIVE]):
            low_w, high_w, low_h, high_h = size[3:7]
            if not (0 < low_w <= high_w and 0 < low_h <= high_h):
                raise ValueError("sensor returned invalid frame-size bounds")
            ranges.add((code, low_w, high_w, low_h, high_h))
            code_sizes.update(((low_w, low_h), (high_w, high_h)))
        for width, height in sorted(code_sizes):
            fields = [0, pad, code, width, height, 0, 0, _ACTIVE]
            for interval in _rows(ioctl, fd, _INTERVAL, 0, fields):
                actual_code, w, h, numerator, denominator = interval[2:7]
                # Some RK drivers enumerate their mode table by index and write back
                # the dimensions. Associate each interval with the returned size.
                if min(numerator, denominator, w, h) == 0 or actual_code != code:
                    raise ValueError("sensor returned an invalid frame interval")
                if not any(c == code and wl <= w <= wh and hl <= h <= hh
                           for c, wl, wh, hl, hh in ranges):
                    raise ValueError("sensor returned a size outside its advertised bounds")
                modes.add((code, w, h, Fraction(numerator, denominator)))
    return {
        "modes": [dict(mbus_code=c, width=w, height=h, interval=_ratio(t), fps=_ratio(1/t))
                  for c, w, h, t in sorted(modes)],
        "size_ranges": [dict(mbus_code=c, min_width=wl, max_width=wh, min_height=hl, max_height=hh)
                        for c, wl, wh, hl, hh in sorted(ranges)],
    }


def _video_driver(sys_root, node):
    link = Path(sys_root, "class", "video4linux", Path(node).name, "device", "driver")
    return link.resolve().name if link.is_symlink() else ""


# Physical controllers wired to the four camera sockets on the AIM-IO carrier.
# Their MMIO addresses stay fixed when Linux renumbers I²C buses or video nodes.
AIM_IO_CONNECTORS = {
    "i2c@feaa0000": "CAM0",
    "i2c@feac0000": "CAM1",
    "i2c@feab0000": "CAM2",
    "i2c@fec80000": "CAM3",
}


def _physical_connector(tree, sensor_of_node):
    try:
        compatible = (tree / "compatible").read_bytes().split(b"\0")
        if b"rockchip,rk3588-armsom-aim7-io" not in compatible:
            return None
        node = sensor_of_node.resolve(strict=True)
        if (node / "reg").read_bytes() != b"\x00\x00\x00\x10":
            return None
        controller = node.parent.relative_to(tree.resolve(strict=True)).as_posix()
    except (OSError, ValueError):
        return None
    return AIM_IO_CONNECTORS.get(controller)


def read_graphs(dev_root):
    graphs = []
    for media in sorted(Path(dev_root).glob("media[0-9]*")):
        if not re.fullmatch(r"media\d+", media.name):
            continue
        topo = subprocess.run(["media-ctl", "-d", str(media), "-p"], text=True,
                              capture_output=True, env={**os.environ, "LC_ALL": "C"}, timeout=10)
        if topo.returncode:
            raise OSError(f"cannot read topology for {media}: {topo.stderr.strip()}")
        graphs.append(parse_graph(str(media), topo.stdout))
    return graphs


def discover_cameras(video_node=None, *, dev_root="/dev", sys_root="/sys", graphs=None):
    if video_node:
        video_node = os.path.realpath(video_node)
        if not re.fullmatch(r"video\d+", Path(video_node).name) or not Path(video_node).exists():
            return [_unmanaged(video_node, "unknown-video-node")]
        if _video_driver(sys_root, video_node) == "uvcvideo":
            return [_unmanaged(video_node, "uvc")]
    if graphs is None:
        graphs = read_graphs(dev_root)
    result = resolve_routes(graphs, video_node)
    if video_node and not result:
        return [_unmanaged(video_node, "not-rkisp-output")]
    if not video_node:
        for node in sorted(Path(dev_root).glob("video[0-9]*")):
            if _video_driver(sys_root, node) == "uvcvideo":
                result.append(_unmanaged(str(node), "uvc"))
    cache = {}
    for camera in result:
        if not camera["managed"]:
            continue
        sensor = camera["sensor"]
        if not re.fullmatch(r"(?:m\d+_[bf]_)?(?:imx219|ov13850)\s+\S+", sensor["entity"]):
            camera.update(managed=False, reason="unsupported-sensor", modes=[])
            continue
        key = (sensor["node"], sensor["pad"])
        if key not in cache:
            import fcntl  # Linux only; tests also exercise the parser on host platforms.
            try:
                with open(key[0], "rb", buffering=0) as device:
                    cache[key] = enumerate_pad(device.fileno(), key[1], fcntl.ioctl)
            except (ValueError, OSError) as exc:
                cache[key] = {"modes": [], "size_ranges": [], "error": str(exc)}
            subdev = Path(sys_root) / "class/video4linux" / Path(sensor["node"]).name
            connector = _physical_connector(Path(sys_root) / "firmware/devicetree/base",
                                            subdev / "device/of_node")
            if connector:
                cache[key]["connector"] = connector
        camera.update(cache[key])
        if not camera["modes"]:
            camera.update(managed=False, reason="no-enumerated-modes")
    return result


def inactive_rk_nodes(graphs, cameras):
    """Find video/subdev nodes belonging exclusively to sensorless RK pipelines."""
    available_cifs = set()
    inactive = set()
    for g in graphs:
        if not g.driver.startswith("rkcif"):
            continue
        streams = [name for name in g.entities if re.fullmatch(r"stream_cif_(?:mipi|dvp)_id\d+", name)]
        if streams:
            connected = any(any(_sensor_paths(g, name, None)) for name in streams)
        else:
            connected = any(e.sensor and e.node for e in g.entities.values())
        if connected:
            available_cifs.add(g.model)
        else:
            inactive.add(g.media)

    no_route = {c["video_node"] for c in cameras if c["reason"] == "no-enabled-route"}
    for g in graphs:
        main = g.entities.get("rkisp_mainpath")
        if not g.driver.startswith("rkisp") or not main or main.node not in no_route:
            continue
        # A working sensor on another virtual channel may be outside the
        # native-mode adapter's VC0 topology. Leave its original driver visible.
        inputs = {src for src, _, dst, pad in g.links if dst == "rkisp-isp-subdev" and pad == 0}
        if not inputs & available_cifs:
            inactive.add(g.media)

    protected = {e.node for g in graphs if g.media not in inactive for e in g.entities.values()}
    return sorted({(e.node, e.name) for g in graphs if g.media in inactive for e in g.entities.values()
                   if e.node not in protected and re.fullmatch(r"/dev/(?:video|v4l-subdev)\d+", e.node)})


def desktop_inventory(dev_root="/dev", sys_root="/sys"):
    graphs = read_graphs(dev_root)
    cameras = discover_cameras(dev_root=dev_root, sys_root=sys_root, graphs=graphs)
    try:
        soc = (Path(sys_root) / "firmware/devicetree/base/compatible").read_bytes().split(b"\0")
    except OSError:
        soc = []
    rkisp_platforms = {b"rockchip,rk3576", b"rockchip,rk3588", b"rockchip,rk3588s"}
    hidden = inactive_rk_nodes(graphs, cameras) if rkisp_platforms.intersection(soc) else []
    return cameras, hidden


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--device", help="resolve a capture video node or its symlink")
    args = parser.parse_args()
    try:
        cameras = discover_cameras(args.device)
    except (OSError, subprocess.SubprocessError) as exc:
        print(f"camera discovery: {exc}", file=sys.stderr)
        return 1
    print(json.dumps({"schema_version": 1, "cameras": cameras}, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
