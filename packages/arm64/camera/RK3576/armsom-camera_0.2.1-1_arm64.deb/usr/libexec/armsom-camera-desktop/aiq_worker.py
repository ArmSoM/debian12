"""Isolated RKAIQ worker using its public uAPI2 C ABI.

Signatures match the SDK uAPI2/rk_aiq_user_api2_sysctl.h and
rk_aiq_user_api_common.h. ISP30 builds without setFrameRate use the public
sysctl_tuning JSON API before prepare, as documented by Rockchip's rkisp_demo.
Opaque contexts avoid reproducing version-specific AE structures in Python.
"""
import ctypes as C
import json
import os
from pathlib import Path
import signal
import sys
import time


class FrameRate(C.Structure):
    _fields_ = [('mode', C.c_int), ('fps', C.c_uint)]


def checked(result, operation):
    if result != 0:
        raise RuntimeError(f'RKAIQ {operation} failed: {result}')


class RkaiqApi:
    def __init__(self, library, profile):
        def bind(name, restype, *types):
            symbol = 'rk_aiq_uapi2_' + name
            try:
                function = getattr(library, symbol)
            except AttributeError as exc:
                raise RuntimeError(f'RKAIQ library is missing {symbol}') from exc
            function.restype = restype
            function.argtypes = list(types)
            return function

        self.preinit = bind('sysctl_preInit', C.c_int, C.c_char_p, C.c_int, C.c_char_p)
        self.init = bind('sysctl_init', C.c_void_p, C.c_char_p, C.c_char_p, C.c_void_p, C.c_void_p)
        self._prepare = bind('sysctl_prepare', C.c_int, C.c_void_p, C.c_uint32, C.c_uint32, C.c_int)
        self.start = bind('sysctl_start', C.c_int, C.c_void_p)
        self.stop = bind('sysctl_stop', C.c_int, C.c_void_p, C.c_bool)
        self.deinit = bind('sysctl_deinit', None, C.c_void_p)
        if hasattr(library, 'rk_aiq_uapi2_setFrameRate'):
            self.fps_control = 'setFrameRate'
            self._set_fps = bind('setFrameRate', C.c_int, C.c_void_p, FrameRate)
            self.iq_frame_rates = []
            for scene in profile.get('main_scene', []):
                for sub in scene.get('sub_scene', []):
                    rate = sub.get('scene_isp39', {}).get('ae_calib', {}).get('commCtrl', {}).get('frmRate', {})
                    self.iq_frame_rates.append(rate.get('sw_aeT_frmRate_val')
                                               if rate.get('sw_aeT_frmRate_mode') == 'ae_frmRate_fix_mode' else None)
        else:
            # Gate the fallback by the actual IQ schema, not a board name.
            # This path is defined by the SDK ISP30 aec_head.h; do not apply it
            # to newer ISP generations with different AE parameter layouts.
            try:
                scenes = [sub for main in profile['main_scene'] for sub in main['sub_scene']]
                fields = [sub['scene_isp30']['ae_calib']['CommCtrl']['AecFrameRateMode'] for sub in scenes]
                supported = bool(fields) and all(isinstance(value, dict) and
                    {'isFpsFix', 'FpsValue'} <= value.keys() for value in fields)
            except (KeyError, TypeError):
                supported = False
            if not supported:
                raise RuntimeError('RKAIQ lacks setFrameRate and the IQ file is not a supported ISP30 profile')
            self.fps_control = 'isp30-sysctl_tuning'
            self._tuning = bind('sysctl_tuning', C.c_int, C.c_void_p, C.c_char_p)

    def frame_rate_control(self, fps):
        if self.fps_control == 'setFrameRate' and int(fps) != fps:
            if self.iq_frame_rates and all(value == fps for value in self.iq_frame_rates):
                return 'isp39-session-iq'
            raise RuntimeError('No calibrated fractional frame-rate control for this profile')
        return self.fps_control

    def prepare(self, context, width, height, fps):
        control = self.frame_rate_control(fps)
        if self.fps_control == 'isp30-sysctl_tuning':
            # Rockchip specifies tuning after init and before prepare. Only the
            # in-use calibration is patched; the original IQ file is untouched.
            patch = json.dumps([{'op': 'replace',
                'path': '/ae_calib/CommCtrl/AecFrameRateMode',
                'value': {'isFpsFix': 1, 'FpsValue': fps}}]).encode()
            checked(self._tuning(context, C.create_string_buffer(patch)), 'sysctl_tuning frame rate')
        checked(self._prepare(context, width, height, 0), 'prepare')
        if control == 'setFrameRate':
            checked(self._set_fps(context, FrameRate(1, int(fps))), 'setFrameRate')


def load_api(config):
    profile = json.loads(Path(config['session_iq']).read_text())
    return RkaiqApi(C.CDLL('librkaiq.so'), profile)


def run(config: dict) -> None:
    # Arm the parent-death signal before creating an AIQ context or leaving the
    # systemd cgroup. Recheck the expected parent to close the fork/exec race.
    if 'broker_pid' in config:
        libc = C.CDLL(None, use_errno=True)
        if libc.prctl(1, signal.SIGTERM, 0, 0, 0) or os.getppid() != config['broker_pid']:
            raise RuntimeError('Broker is no longer available')
    # This SDK enables CONFIG_RT_GROUP_SCHED. RKAIQ's SCHED_RR statistics
    # threads need the root cgroup, just as the existing rkaiq_3A service does.
    root = Path('/sys/fs/cgroup/cgroup.procs')
    if root.exists():
        root.write_text(str(os.getpid()))
    os.environ['HDR_MODE'] = '0'
    api = load_api(config)
    print(f'RKAIQ FPS control: {api.frame_rate_control(config["fps"])}', flush=True)

    running = True
    def end(*_):
        nonlocal running
        running = False

    signal.signal(signal.SIGINT, end)
    signal.signal(signal.SIGTERM, end)
    # Normal parent cleanup handles SIGINT/TERM; this also prevents an orphan
    # from retaining the ISP after the controlling process dies unexpectedly.
    parent = os.getppid()
    sensor = config['sensor'].encode()
    profile = Path(config['session_iq'])
    checked(api.preinit(sensor, 0, profile.name.encode()), 'preInit')
    context = api.init(sensor, str(profile.parent).encode(), None, None)
    if not context:
        raise RuntimeError('RKAIQ init returned NULL')
    started = False
    try:
        api.prepare(context, config['sensor_width'], config['sensor_height'], config['fps'])
        checked(api.start(context), 'start')
        started = True
        Path(config['ready']).write_text('ready\n')
        while running and os.getppid() == parent:
            time.sleep(0.1)
    finally:
        try:
            if started:
                checked(api.stop(context, False), 'stop')
        finally:
            api.deinit(context)


if __name__ == '__main__':
    if len(sys.argv) == 3 and sys.argv[1] == '--check':
        # Resolve symbols/schema in a separate process, without starting AIQ.
        config = json.loads(Path(sys.argv[2]).read_text())
        print(load_api(config).frame_rate_control(config['fps']))
    else:
        run(json.loads(Path(sys.argv[1]).read_text()))
